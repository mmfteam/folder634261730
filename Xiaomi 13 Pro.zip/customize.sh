#!/system/bin/sh

SKIPUNZIP=1
sleep 0.5

PRINT() {
    ui_print "Xiaomi 13 Pro"
    sleep 0.5
}

EXEC() {
    ui_print "Installing..."
    sleep 0.5
    ui_print "- Extracting module files"
    unzip -o "$ZIPFILE" module.prop -d $MODPATH >&2
    unzip -o "$ZIPFILE" post-fs-data.sh -d $MODPATH >&2
    unzip -o "$ZIPFILE" service.sh -d $MODPATH >&2
    unzip -o "$ZIPFILE" system.prop -d $MODPATH >&2
    unzip -o "$ZIPFILE" uninstall.sh -d $MODPATH >&2
    sleep 0.5
    
    ui_print "- Settings module"
    sed -i "s/ro.product.brand/ro.product.brand=Xiaomi/" $MODPATH/system.prop
    sed -i "s/ro.product.manufacturer/ro.product.manufacturer=Xiaomi/" $MODPATH/system.prop
    sed -i "s/ro.product.marketname/ro.product.marketname=Xiaomi 13 Pro/" $MODPATH/system.prop
    sed -i "s/ro.product.model/ro.product.model=2210132G/" $MODPATH/system.prop
    sed -i "s/ro.product.name/ro.product.name=nuwa_global/" $MODPATH/system.prop
    sed -i "s/ro.product.odm.brand/ro.product.odm.brand=Xiaomi/" $MODPATH/system.prop
    sed -i "s/ro.product.odm.manufacturer/ro.product.odm.manufacturer=Xiaomi/" $MODPATH/system.prop
    sed -i "s/ro.product.odm.marketname/ro.product.odm.marketname=Xiaomi 13 Pro/" $MODPATH/system.prop
    sed -i "s/ro.product.odm.model/ro.product.odm.model=2210132G/" $MODPATH/system.prop
    sed -i "s/ro.product.odm.name/ro.product.odm.name=nuwa_global/" $MODPATH/system.prop
    sed -i "s/ro.product.product.brand/ro.product.product.brand=Xiaomi/" $MODPATH/system.prop
    sed -i "s/ro.product.product.manufacturer/ro.product.product.manufacturer=Xiaomi/" $MODPATH/system.prop
    sed -i "s/ro.product.product.marketname/ro.product.product.marketname=Xiaomi 13 Pro/" $MODPATH/system.prop
    sed -i "s/ro.product.product.model/ro.product.product.model=2210132G/" $MODPATH/system.prop
    sed -i "s/ro.product.product.name/ro.product.product.name=nuwa_global/" $MODPATH/system.prop
    sed -i "s/ro.product.system.brand/ro.product.system.brand=Xiaomi/" $MODPATH/system.prop
    sed -i "s/ro.product.system.manufacturer/ro.product.system.manufacturer=Xiaomi/" $MODPATH/system.prop
    sed -i "s/ro.product.system.marketname/ro.product.system.marketname=Xiaomi 13 Pro/" $MODPATH/system.prop
    sed -i "s/ro.product.system.model/ro.product.system.model=2210132G/" $MODPATH/system.prop
    sed -i "s/ro.product.system.name/ro.product.system.name=nuwa_global/" $MODPATH/system.prop
    sed -i "s/ro.product.system_ext.brand/ro.product.system_ext.brand=Xiaomi/" $MODPATH/system.prop
    sed -i "s/ro.product.system_ext.manufacturer/ro.product.system_ext.manufacturer=Xiaomi/" $MODPATH/system.prop
    sed -i "s/ro.product.system_ext.marketname/ro.product.system_ext.marketname=Xiaomi 13 Pro/" $MODPATH/system.prop
    sed -i "s/ro.product.system_ext.model/ro.product.system_ext.model=2210132G/" $MODPATH/system.prop
    sed -i "s/ro.product.system_ext.name/ro.product.system_ext.name=nuwa_global/" $MODPATH/system.prop
    sed -i "s/ro.product.vendor.brand/ro.product.vendor.brand=Xiaomi/" $MODPATH/system.prop
    sed -i "s/ro.product.vendor.manufacturer/ro.product.vendor.manufacturer=Xiaomi/" $MODPATH/system.prop
    sed -i "s/ro.product.vendor.marketname/ro.product.vendor.marketname=Xiaomi 13 Pro/" $MODPATH/system.prop
    sed -i "s/ro.product.vendor.model/ro.product.vendor.model=2210132G/" $MODPATH/system.prop
    sed -i "s/ro.product.vendor.name/ro.product.vendor.name=nuwa_global/" $MODPATH/system.prop
}

if [ ! "$SKIPUNZIP" = "0" ]; then
    set -x
    PRINT
    EXEC
else
    set +x
    abort
fi
